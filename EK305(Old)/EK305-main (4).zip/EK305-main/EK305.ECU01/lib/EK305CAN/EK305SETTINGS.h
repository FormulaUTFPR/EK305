﻿////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Nome da biblioteca: EK305CAN_SETTINGS                                                                                              //
// Nome do arquivo: EK305CAN_SETTINGS.h                                                                                               //
// Data/versão: 22/02/2021 (v1.0.0)                                                                                                   //
// IDE utilizada: Visual Studio Code & PlatformIO                                                                                     //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef EK305CAN_SETTINGS_H_
#define EK305CAN_SETTINGS_H_

#define EK305CAN_ID_ADDRESS_THIS EK305CAN_ID_ADDRESS_ECU01

#endif