/* -------------------------------------------------------------------- */
//                     MÓDULO 04 - ATMEGA328P
// || SENSOR  ||                    || CÓDIGO  ||            ||  TESTE  ||
// Temperatura Restritor/Turbo	    MTE5053
// Temperatura Turbo/Intercooler	  MTE5053
// Temperatura Saída Intercooler	  MTE5053
// Pressão Restritor/Turbo	        MTE7133
// Pressão Turbo/Intercooler	      MTE7133
// Pressão Saída Intercooler	      MTE7133
// Indicador de Marcha	            Original Moto
/* -------------------------------------------------------------------- */

#include <Arduino.h>

void setup()
{
  // put your setup code here, to run once:
}

void loop()
{
  // put your main code here, to run repeatedly:
}